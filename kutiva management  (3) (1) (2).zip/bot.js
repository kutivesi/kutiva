const TelegramBot = require('node-telegram-bot-api');
const { initializeApp } = require('firebase/app');
const { getAuth, signInWithEmailAndPassword } = require('firebase/auth');
const { getFirestore, collection, query, where, getDocs } = require('firebase/firestore');

// Configuração do Firebase
const firebaseConfig = {
    apiKey: "AIzaSyAgpwyV-nXP7U0MkLZSb7JsBx0TnDVkMz8",
    authDomain: "kutiva-8a875.firebaseapp.com",
    projectId: "kutiva-8a875",
    storageBucket: "kutiva-8a875.appspot.com",
    messagingSenderId: "293924144980",
    appId: "1:293924144980:android:a7de770e962d945db36ac1"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Token do bot do Telegram
const token = '8034642483:AAFRTzvrCAbWz9WCzaqvCqIn2Vi3OJwWfX4';

// Criar o bot
const bot = new TelegramBot(token, { polling: true });

// Estado de autenticação dos usuários
let userSession = {};

// Comando /start
bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, "Por favor, inicie a sessão na sua conta.\nEmail: ''coloque aqui o seu email''\nSenha: ''coloque aqui a sua senha, está segura comigo''.");
});

// Receber o e-mail do usuário
bot.on('message', (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;

    if (text.includes('@')) {
        // O usuário está fornecendo o e-mail
        userSession[chatId] = { email: text };
        bot.sendMessage(chatId, "Agora, por favor, insira sua senha.");
    } else if (userSession[chatId] && !userSession[chatId].password) {
        // O usuário está fornecendo a senha
        userSession[chatId].password = text;

        // Autenticação Firebase
        signInWithEmailAndPassword(auth, userSession[chatId].email, userSession[chatId].password)
            .then((userCredential) => {
                bot.sendMessage(chatId, "Autenticação bem-sucedida! Por favor, apague a mensagem contendo suas credenciais.");
                listarComandos(chatId);
            })
            .catch((error) => {
                bot.sendMessage(chatId, "Erro de autenticação. Por favor, tente novamente.");
                delete userSession[chatId];
            });
    } else if (text === '/livro' || text === '/modulo' || text === '/exame') {
        // Se o usuário estiver selecionando uma categoria
        selecionarClasse(chatId, text);
    }
});

// Função para listar os comandos
function listarComandos(chatId) {
    bot.sendMessage(chatId, `Comandos disponíveis:
    /busca - Buscar por categorias
    /livro - Buscar livros
    /modulo - Buscar módulos
    /exame - Buscar exames`);
}

// Função para selecionar a classe
function selecionarClasse(chatId, category) {
    const classes = ['7ª Classe', '8ª Classe', '9ª Classe', '10ª Classe', '11ª Classe', '12ª Classe'];
    const classesStr = classes.join('\n');
    bot.sendMessage(chatId, `Selecione uma classe:\n${classesStr}`);
    userSession[chatId].category = category; // Armazena a categoria escolhida
}

// Receber a classe selecionada
bot.on('message', (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;

    if (userSession[chatId] && userSession[chatId].category) {
        // Se o usuário já selecionou uma categoria
        const selectedClass = text;

        if (['7ª Classe', '8ª Classe', '9ª Classe', '10ª Classe', '11ª Classe', '12ª Classe'].includes(selectedClass)) {
            buscarConteudo(chatId, selectedClass, userSession[chatId].category);
        } else {
            bot.sendMessage(chatId, "Classe inválida. Por favor, selecione uma classe válida.");
        }
    }
});

// Função para buscar conteúdo no Firestore
function buscarConteudo(chatId, selectedClass, category) {
    let collectionName = '';
    if (category === '/livro') {
        collectionName = 'books';
    } else if (category === '/modulo') {
        collectionName = 'modulos';
    } else if (category === '/exame') {
        collectionName = 'exames';
    }

    const q = query(collection(db, collectionName), where("class", "==", selectedClass));
    getDocs(q)
        .then((querySnapshot) => {
            if (querySnapshot.empty) {
                bot.sendMessage(chatId, `Nenhum ${category === '/livro' ? 'livro' : category === '/modulo' ? 'módulo' : 'exame'} encontrado para a ${selectedClass}.`);
            } else {
                querySnapshot.forEach((doc) => {
                    const item = doc.data();
                    bot.sendPhoto(chatId, item.imageUrl, {
                        caption: `${item.title}\nLink: ${item.link}`
                    });
                });
            }
        })
        .catch((error) => {
            console.error(`Erro ao carregar ${category}: `, error);
            bot.sendMessage(chatId, `Erro ao buscar ${category}. Tente novamente.`);
        });
}

// Comandos para buscar
bot.onText(/\/busca/, (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, "Escolha uma categoria: \n/livro \n/modulo \n/exame");
});
